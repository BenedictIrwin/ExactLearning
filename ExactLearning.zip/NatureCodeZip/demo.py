'''
Exact Learning DEMO
Benedict Irwin, 2021
'''
from exactlearning import *
import os

## Welcome to the DEMO, we are going to use the exact learning formalism to find the exact solution
## to a numerical solution of the time-independent Schrodinger equation, with a harmonic oscillator potential

## Step 1, numerically solve the Schrodinger equation
## This is an example of a scientific problem that generates a high resolution output
## In this case we get a numerical solution, we numerically interpolate it and numerically integrate it
## to extract the complex momements

os.system("python solve_schrodinger_equation.py")

## See Figure1.png for the solution

## Now we have the files:
## logmoments_{Harmonic_4}.npy
## s_values_{Harmonic_4}.npy
## we can invoke Exact Learning, by assuming a few ansatz for the 'fingerprint'

## Also now see Figure2 for the complex moments of the solution
## See Figure 3 for the complex log-moments (which we will be fitting)
## Please see the supplementary material of the paper for a few more examples

## An exact estimator class
estimator = ExactEstimator("Harmonic_4")

## Define some common fingerprint forms
## For example: phi(s) ~ c*Gamma(a*s + b)
## The product is taken over terms in the list
fingerprints = [
        gen_fpdict(['c','linear-gamma']),
        #gen_fpdict(['c^s','linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma']),
        #gen_fpdict(['c','c^s','neg-linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma','neg-linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma','neg-linear-gamma','linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma','neg-linear-gamma','neg-linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma','linear-gamma','neg-linear-gamma','neg-linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma','linear-gamma','linear-gamma','neg-linear-gamma','neg-linear-gamma','neg-linear-gamma']),
        #gen_fpdict(['c','linear-gamma','linear-gamma','neg-linear-gamma','neg-linear-gamma']),
        #gen_fpdict(['c','linear-gamma','linear-gamma','linear-gamma','neg-linear-gamma','neg-linear-gamma','neg-linear-gamma']),
        #gen_fpdict(['c','c^s','linear-gamma','neg-linear-gamma']),
        gen_fpdict(['c','c^s','linear-gamma','P1']),
        gen_fpdict(['c','c^s','linear-gamma','P2']),
        gen_fpdict(['c','c^s','linear-gamma','neg-linear-gamma','P1']),
        gen_fpdict(['c','c^s','linear-gamma','neg-linear-gamma','P2']),
        #gen_fpdict(['c','c^s','2F1'],N=4),
        #gen_fpdict(['c','c^s','2F1','linear-gamma'],N=4),
        #gen_fpdict(['c','c^s','2F1','linear-gamma','neg-linear-gamma'],N=4)
        ]

## Looping over fingerprints to see which is the best fit
for fpt in fingerprints:
  ## Set the fingerprint to be the one the estimator is using
  estimator.set_fingerprint(fpt)
  ## for each fingerprint, try fitting 10 times via complex BFGS
  for _ in range(10):
    estimator.BFGS()

## The estimator stores up the best results
## Finally, speculate on the nature of the constants invoved
## A prebuilt list of common constants is used and a nearest neighbour search made
## Different terms in the fingerprints tend to draw on different pools of constants (i.e. rationals)
estimator.speculate()


