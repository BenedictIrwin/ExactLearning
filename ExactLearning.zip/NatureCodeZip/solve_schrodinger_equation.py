import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d
from scipy.interpolate import interp1d
import scipy.integrate as integrate

#####################################
## Solve the Differential Equation ##
#####################################

## Define some constants
## Define Resolution (ODD NUMBER), and midpoint
hbar, m, omega = 1, 1, 1
N = 515
center = int((N-1)/2)

## Define the width of the numerical solution
a = 18.0
x = np.linspace(-a/2.0,a/2.0,N)

## Define the potential as harmonic oscillator potential
V = (1/2)*m*omega*x**2 

## Define the differential 'epsilon'
epsilon = x[1]-x[0] # ~ 2*np.pi/(N-1)

## Define the Hamiltonian (H) of the system to take the eigenstates
second_derivative_operator = (np.diag(np.ones(N-1),-1) -2.0*np.diag(np.ones(N),0) + np.diag(np.ones(N-1),1))/(epsilon**2)
H = -(hbar*hbar)/(2.0*m) * second_derivative_operator + np.diag(V) 

## The energy levels are the eigenvalues (En) and the wavefunctions are the eigenvectors (psi)
En, psiT = np.linalg.eigh(H)
psi = np.transpose(psiT) 

## Define the order of the solution we are interested in and the sign to flip the function
order = 4
sign = -1 * (-1)**order 

###############################
## Interpolation/Integration ##
###############################

## We can interpolate this with cubic splines
psi_inp = interp1d(x[center:],(psi[order]/np.sqrt(epsilon))[center:] , kind='cubic')

## Define a cutoff for the purposes of numeric integration
x_max = 9

## Define functions for real and imaginary integration
def real_integrand(x,s): return np.real(x**(s-1)*psi_inp(x))
def imag_integrand(x,s): return np.imag(x**(s-1)*psi_inp(x))
def special_int(s):  
  r = integrate.quad(real_integrand, 0, x_max, args=(s))
  i = integrate.quad(imag_integrand, 0, x_max, args=(s))
  return r[0]+ 1j*i[0], r[1], i[1]

## Vectorize the function
vec_int = np.vectorize(special_int)

## We can plot the energy level, the wavefunction and the potential for illustration
plt.plot(x,10*sign*psi[order]/np.sqrt(epsilon)+En[order],label = "$\psi_{}$(x)".format(order))
plt.plot(x,0.1*V,label="V(x)")
plt.xlabel("x")
plt.ylabel("V(x) or $\psi$(x)")
plt.legend()
plt.savefig("Figure1.png")

##############################
## Generate complex moments ##
##############################

## Choose a number of moments to sample!
## Higher the better, but more expensive to fit
N_s = 500

## Define a sampling grid in complex moment space
s1 = np.random.uniform(low = 1, high =6, size = N_s)
s2 = np.random.uniform(low = -0.9*np.pi, high = 0.9*np.pi, size = N_s)

## Define the list of complex moments
s = [ t1 + t2*1j for t1,t2 in zip(s1,s2) ]

## Perform the integration (i.e. the numeric Mellin transform)
## This returns the moments (q), the real and imaginary errors (qre), (qie)
q, qre, qie = vec_int(s)

if(True):
  ax = plt.axes(projection='3d')
  # Data for three-dimensional scattered points
  ax.scatter3D(np.real(s), np.imag(s), np.real(q), c=np.real(q), cmap='Reds');
  ax.scatter3D(np.real(s), np.imag(s), np.imag(q), c=np.imag(q), cmap='Greens');
  ax.set_xlabel('Re(s)')
  ax.set_ylabel('Im(s)')
  ax.set_zlabel('$E[x^{s-1}]$')
  #plt.show()
  plt.savefig("Figure2.png")
  
  ax = plt.axes(projection='3d')
  # Data for three-dimensional scattered points
  ax.scatter3D(np.real(s), np.imag(s), np.real(np.log(q)), c=np.real(np.log(q)), cmap='Reds');
  ax.scatter3D(np.real(s), np.imag(s), np.imag(np.log(q)), c=np.imag(np.log(q)), cmap='Greens');
  ax.set_xlabel('Re(s)')
  ax.set_ylabel('Im(s)')
  ax.set_zlabel('$\log E[x^{s-1}]$')
  #plt.show()
  plt.savefig("Figure3.png")

## Save the outputs for the ExactEstimator to use
np.save("s_values_Harmonic_{}".format(order),s)
np.save("moments_Harmonic_{}".format(order),q)
np.save("logmoments_Harmonic_{}".format(order),np.log(q))
np.save("real_error_Harmonic_{}".format(order),qre)
np.save("imag_error_Harmonic_{}".format(order),qie)
