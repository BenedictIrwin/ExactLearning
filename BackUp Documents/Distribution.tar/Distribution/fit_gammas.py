import numpy as np
from scipy.special import loggamma
from scipy.optimize import curve_fit

logmoments = np.load("logmoments.npy")
s_values = np.load("s_values.npy")

def func(s, a, b): 
  return loggamma(np.dot(a,s) + b)

plt.plot(s,q)
popt, pcov = curve_fit(func, xdata, ydata)
